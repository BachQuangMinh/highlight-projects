class TextrankRuntimeError(RuntimeError):
    pass